# ExamCellAutomation
Examination Cell Automation System is developed for the college to simplify the allocation of halls .It facilitates to access the examination information of a particular student in a particular department. Here the admin updates the student details,exam timings,hall details,staff details and available space in the hall.So the automated system will give the seating details to the students whose details were listed in the database.The purpose of developing exam cell automation system is to computerize the traditional way of conducting the exams.Another purpose for developing this software is to generate the seating arrangement report automatically during exams at the end of the session or in between the session.


The system is developed using HTML/CSS for front end,MySQL database for backend and for connectivity PHP is used. 

![](Images/Screenshot%20from%202018-03-28%2006-49-13.png)
![](Images/Screenshot%20from%202018-03-28%2006-51-35.png)
![](Images/Screenshot%20from%202018-03-28%2006-53-14.png)
![](Images/Screenshot%20from%202018-03-28%2006-53-27.png)
![](Images/Screenshot%20from%202018-03-28%2006-53-43.png)
![](Images/Screenshot%20from%202018-03-28%2006-53-51.png)

 	
