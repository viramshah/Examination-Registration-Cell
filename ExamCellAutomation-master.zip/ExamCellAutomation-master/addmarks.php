<?php
include 'connect.php';
$seat = $_POST["seat"];




mysqli_close($con);
?>
