<?php


$db_server = "localhost";
$db_name = "testdb";
$db_user = "root";
$db_pwd = "12345";

$con = mysqli_connect($db_server,$db_user,$db_pwd,$db_name);


?>
